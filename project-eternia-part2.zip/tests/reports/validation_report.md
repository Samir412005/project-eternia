# Validation Report — PROJECT ETERNIA Phase 1

Date (UTC): 2026-11-14T23:43:21Z
Godot: /home/hatch/workspace/game-apk/godot/Godot_v4.3-stable_linux.x86_64

## 1. Godot version
4.3.stable.official.77dcf97d8

## 2. Project import (headless)
Godot Engine v4.3.stable.official.77dcf97d8 - https://godotengine.org

import exit: 0

## 3. Automated tests (tests/run_tests.gd)
Godot Engine v4.3.stable.official.77dcf97d8 - https://godotengine.org

TEST PASS main_scene_loads
TEST PASS main_instantiates
TEST PASS player_exists
TEST PASS world_exists
TEST PASS shrine_exists
TEST PASS hud_exists
TEST PASS camera_exists
TEST PASS world_has_content
TEST PASS player_speeds_sane
TEST PASS player_gravity_set
TEST PASS player_scene_loads
TEST PASS inventory_add
TEST PASS inventory_remove
TEST PASS inventory_reject_overdraw
TEST PASS xp_accumulates
TEST PASS level_up_works
TEST PASS quest_db_loads
TEST PASS quest_starts
TEST PASS quest_completes
TEST PASS save_roundtrip
TEST PASS save_rejects_bad_version
TEST PASS all_scripts_parse
TEST SUMMARY passed=22 failed=0
ERROR: Parameter "m" is null.
   at: mesh_get_surface_count (servers/rendering/dummy/storage/mesh_storage.h:120)

## 4. Headless run of main scene (10 seconds)
Godot Engine v4.3.stable.official.77dcf97d8 - https://godotengine.org

ERROR: Parameter "m" is null.
   at: mesh_get_surface_count (servers/rendering/dummy/storage/mesh_storage.h:120)

## 5. APK artifact
total 0
drwxrws--- 1 root nogroup  0 Nov 15 00:41 .
drwxrws--- 1 root nogroup 14 Nov 15 00:41 ..
